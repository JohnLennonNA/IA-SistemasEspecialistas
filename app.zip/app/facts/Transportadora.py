from pyknow import *

class Transportadora(Fact):
    pass