from pyknow import *

class Evento(Fact):
    pass
