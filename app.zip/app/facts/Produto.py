from pyknow import *


class Produto(Fact):
    pass
