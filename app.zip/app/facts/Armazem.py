from pyknow import *

class Armazem(Fact):
    pass