from pyknow import *

class Cliente(Fact):
    pass