from pyknow import *

class Ocorrencia(Fact):
    status = Field(str, mandatory=False)

